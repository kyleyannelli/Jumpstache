<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="freetileset" tilewidth="32" tileheight="32" tilecount="11" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="37">
  <image width="32" height="32" source="tileset/1.png"/>
 </tile>
 <tile id="38">
  <image width="32" height="32" source="tileset/2.png"/>
 </tile>
 <tile id="39">
  <image width="32" height="32" source="tileset/3.png"/>
 </tile>
 <tile id="43">
  <image width="32" height="32" source="tileset/7.png"/>
 </tile>
 <tile id="47">
  <image width="32" height="32" source="tileset/11.png"/>
 </tile>
 <tile id="48">
  <image width="32" height="32" source="tileset/12.png"/>
 </tile>
 <tile id="51">
  <image width="32" height="23" source="tileset/15.png"/>
 </tile>
 <tile id="52">
  <image width="32" height="23" source="tileset/16.png"/>
 </tile>
 <tile id="53">
  <image width="32" height="23" source="tileset/17.png"/>
 </tile>
 <tile id="54">
  <image width="32" height="32" source="tileset/18.png"/>
 </tile>
 <tile id="55">
  <image width="32" height="32" source="tileset/1222.png"/>
 </tile>
</tileset>
