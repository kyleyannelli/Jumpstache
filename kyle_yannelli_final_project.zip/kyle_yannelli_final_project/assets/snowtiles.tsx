<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="snowtiles" tilewidth="32" tileheight="32" tilecount="55" columns="11">
 <image source="snowtileset/snowtilesetpng.png" width="352" height="160"/>
</tileset>
