<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="snowtileset" tilewidth="16" tileheight="16" tilecount="55" columns="11">
 <image source="snowtileset/SnowLand/Sprites/01 - Tileset.png" width="176" height="80"/>
</tileset>
