package com.kyleyannelli.finalproject;

public class EvilGuy extends Guy{
    public EvilGuy(float x, float y, String neutralPath) {
        super(x, y, neutralPath);
    }

    
}
