package com.kyleyannelli.finalproject;

import com.badlogic.gdx.math.Rectangle;

public class RectangleHelper {
    public Rectangle r;
    public byte id;

    public RectangleHelper(Rectangle r, byte id) {
        this.r = r;
        this.id = id;
    }
}
